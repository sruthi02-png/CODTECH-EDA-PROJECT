
# CODTECH Internship - Exploratory Data Analysis (EDA)

## Intern Details
- INTERN ID: CITS1890
- FULL NAME: Sabbavarapu Sri Sruthilaya
- DOMAIN: Data Science & Analytics
- PROJECT NAME: Exploratory Data Analysis on Customer Dataset
- PROJECT SCOPE: Data Cleaning, Visualization, Analysis, Dashboard-ready insights
- NO. OF WEEKS: 4 Weeks

---

## Project Description
This project performs Exploratory Data Analysis (EDA) on a customer dataset.  
The goal is to understand customer behavior using statistical analysis and data visualization.

---

## Files Included

### Dataset Files
- customer_data.csv

### Notebook / Code
- eda_analysis.py

### Graphs & Charts
- Age Distribution
- Income vs Purchase Amount

### Documentation
- Project Report

### Output Screenshots
- Visualization Screenshots

---

## Technologies Used
- Python
- Pandas
- Matplotlib

---

## Steps Performed
1. Data Collection
2. Data Cleaning
3. Statistical Analysis
4. Data Visualization
5. Insight Generation

---

## Conclusion
The project successfully analyzed customer behavior patterns using EDA techniques.

