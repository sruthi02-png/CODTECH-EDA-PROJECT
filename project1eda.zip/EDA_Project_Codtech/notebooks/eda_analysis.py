"""
CODTECH Internship - Exploratory Data Analysis Project
Project Name: Customer Behavior Analysis using EDA
"""

import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("dataset/customer_data.csv")

# Display first 5 rows
print(df.head())

# Dataset information
print(df.info())

# Statistical summary
print(df.describe())

# Missing values
print(df.isnull().sum())

# Histogram
df["Age"].hist()
plt.title("Age Distribution")
plt.xlabel("Age")
plt.ylabel("Count")
plt.show()

# Scatter Plot
plt.scatter(df["Monthly_Income"], df["Purchase_Amount"])
plt.title("Income vs Purchase Amount")
plt.xlabel("Monthly Income")
plt.ylabel("Purchase Amount")
plt.show()

print("EDA Completed Successfully")
